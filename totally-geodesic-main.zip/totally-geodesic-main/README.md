# totally-geodesic
Finding totally geodesic surfaces in a 3-manifold

This code and data accompanies the paper Totally geodesic surfaces in hyperbolic 3-manifolds: algorithms and examples
by Brannon Basilio, Chaeryn Lee, and Joseph Malionek.
